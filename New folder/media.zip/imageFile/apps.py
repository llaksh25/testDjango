from django.apps import AppConfig


class ImagefileConfig(AppConfig):
    name = 'imageFile'
