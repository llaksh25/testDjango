from django.apps import AppConfig


class ExcelhandlerConfig(AppConfig):
    name = 'ExcelHandler'
