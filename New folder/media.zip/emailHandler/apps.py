from django.apps import AppConfig


class EmailhandlerConfig(AppConfig):
    name = 'emailHandler'
